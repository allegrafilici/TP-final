from fantasmas import Fantasma

class Inky(Fantasma):

    def __init__(self, direccion, posicion, modo):

        super().__init__(
            "Inky",
            direccion,
            posicion,
            "Celeste",
            modo
        )s

    def elegir_target(self, pacman, blinky):
        pac_x, pac_y = pacman.posicion
        direc_x, direc_y = pacman.direccion

        tile_adelantado_x = pac_x + direc_x * 2
        tile_adelantado_y = pac_y + direc_y * 2

        blinky_x, blinky_y = blinky.posicion

        vector_x = (tile_adelantado_x - blinky_x) * 2
        vector_y = (tile_adelantado_y - blinky_y) * 2





        target_x = blinky_x + vector_x
        target_y = blinky_y + vector_y

        return (target_x, target_y)

# CLASE TEMPORAL SOLO PARA PROBAR
class PacmanPrueba:
    def __init__(self, posicion, direccion):
        self.posicion = posicion
        self.direccion = direccion


class BlinkyPrueba:
    def __init__(self, posicion):
        self.posicion = posicion


# PRUEBA
pacman = PacmanPrueba(
    (10, 5),   # posicion
    (1, 0)     # direccion derecha
)

blinky = BlinkyPrueba(
    (8, 5)     # posicion de Blinky
)

inky1 = Inky(
    (1, 0),
    (5, 5),
    "chase"
)

print(inky1.nombre)

print("Posicion inicial:")
print(inky1.posicion)

print("Target de Inky:")
print(inky1.elegir_target(pacman, blinky))





     



















        


         
    

    
    


