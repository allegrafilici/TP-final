#logica de clyde seria si esta lejos lo persigue al pacman 
# si esta cerca se escapa  # para poder caluclar la distancia entre el pacman y clyde 
from fantasmas import Fantasma

class Clyde(Fantasma):
    def __init__(self, direccion, posicion, modo):

        super().__init__(
            "Clyde",
            direccion,
            posicion,
            "naranja",
            modo
        )

    def elegir_target(self,pacman):
        pac_x, pac_y = pacman.posicion #separamos posicion pacman 
        cly_x, cly_y = self.posicion #separamos posicoin clyde
        distancia = ((pac_x - cly_x) ** 2 + ( pac_y - cly_y ) ** 2) ** 0.5
        #usaremos 8 como parametro de distancia para ver si esta lejos o cerca 

        if distancia > 8:
            return pacman.posicion #esta lejos para hacer que el pacman sea su tagret
        
        else: 
            return (0,0) # se escapa a una esquina si esta cerca del pacman 


# CLASE TEMPORAL SOLO PARA PROBAR
class PacmanPrueba:
    def __init__(self, posicion):
        self.posicion = posicion


# PRUEBA
pacman = PacmanPrueba((10, 5))

clyde1 = Clyde(
    (1, 0),     # direccion inicial
    (2, 5),     # posicion inicial de Clyde
    "chase"     # modo
)

print(clyde1.nombre)

print("Posicion inicial:")
print(clyde1.posicion)

print("Target de Clyde:")
print(clyde1.elegir_target(pacman))

clyde1.decidir_direccion(pacman)
clyde1.movimiento()

print("Nueva posicion:")
print(clyde1.posicion)

#Para Clyde, la idea es: si está lejos de Pac-Man, el target debería ser Pac-Man; si está cerca, el target debería ser una esquina.















